# Androids Crafted Care

Focused RimWorld mod: robot (crafted android) tending via workgiver, gains Crafting skill XP, uses repairParts as medicine; organic/doctor tending unchanged.

## What it does
- Harmony patch on `Toils_Tend.FinalizeTend`: android patients (tagged `CraftedCareMechanicalProperties`) are tended through a workgiver robot path, learning Crafting skill XP, using repairParts as medicine.
- Organic/doctor tending left untouched (androids do not receive doctor medicine).
- No organic surgery changes.

## Dependencies
- Harmony (Mlie.Harmony)
- Androids (chjees.androidscraftedcare)

## Build
```
dotnet build AndroidsCraftedCare.csproj -c Release
```
References local assemblies from `/root/rimworld_libs` (Assembly-CSharp, RimWorld, 0Harmony). Produces `AndroidsCraftedCare.dll`.

## Testing
`tests/` runs genuine assembly patch binding + classifier + workgiver policy checks against the compiled DLL.

## Note
In-game behavior NOT tested — this is a build/compile artifact. Do not install/publish without playtesting.
